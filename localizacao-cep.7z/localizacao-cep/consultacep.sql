SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE `consultacep` (
  `idConsultaCEP` int(11) NOT NULL,
  `cep` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `logradouro` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `bairro` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uf` varchar(2) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


ALTER TABLE `consultacep`
  ADD PRIMARY KEY (`idConsultaCEP`);


ALTER TABLE `consultacep`
  MODIFY `idConsultaCEP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
