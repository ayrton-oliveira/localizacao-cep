<html>
    <head>
    <title>ViaCEP Webservice</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
    <script type="text/javascript" >
    function limpa_formulário_cep() {
            document.getElementById('logradouro').value=("");
            document.getElementById('bairro').value=("");
            document.getElementById('uf').value=("");
    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            document.getElementById('logradouro').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('uf').value=(conteudo.uf);
        }

        else {
            limpa_formulário_cep();
            alert("CEP não encontrado.");
        }

    }
    function pesquisacep(valor) {
        var cep = valor.replace(/\D/g, '');
        if (cep != "") {
            var validacep = /^[0-9]{8}$/;
            if(validacep.test(cep)) {
                document.getElementById('logradouro').value="...";
                document.getElementById('bairro').value="...";
                document.getElementById('uf').value="...";

                var script = document.createElement('script');

                script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                document.body.appendChild(script);
            } 
            else {

                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
            }
        } 
        else {

            limpa_formulário_cep();
        }
    };

    </script>
    </head>

    <body>
        <div class="row">
            <div class="container-fluid">
                <form method="get" action="gravar.php">
                    <label>Cep:
                    <input name="cep" type="text" id="cep" value="" size="10" maxlength="9"
                        onblur="pesquisacep(this.value);" /></label><br />

                    <label>Logradouro:
                    <input name="logradouro" type="text" id="logradouro" size="60" /></label><br />

                    <label>Bairro:
                    <input name="bairro" type="text" id="bairro" size="40" /></label><br />

                    <label>UF:
                    <input name="uf" type="text" id="uf" size="40" /></label><br />
                
                    <input type="submit" value="GRAVAR">
                    
                </form>
            </div>
        </div>
    </body>
    </html>